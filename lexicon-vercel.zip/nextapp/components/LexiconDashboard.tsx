"use client";

import { useState } from "react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

// ── Types ──────────────────────────────────────────────────

interface Topic {
  id: number;
  title: string;
  entries: number;
  score: number;
  tags: string[];
  trend: string;
}

interface Entry {
  id: number;
  author: string;
  avatar: string;
  topic: string;
  content: string;
  time: string;
  votes: number;
  isAnonymous: boolean;
  flagged: boolean;
}

interface AIFlag {
  id: number;
  type: string;
  confidence: number;
  entry: string;
  reviewed: boolean;
  time: string;
}

interface Plan {
  name: string;
  monthly: number;
  tenants: number;
  revenue: number;
  color: string;
}

// ── Mock Data ──────────────────────────────────────────────

const analyticsData = [
  { day: "Mon", entries: 142, users: 68 },
  { day: "Tue", entries: 198, users: 94 },
  { day: "Wed", entries: 167, users: 77 },
  { day: "Thu", entries: 289, users: 132 },
  { day: "Fri", entries: 341, users: 158 },
  { day: "Sat", entries: 412, users: 189 },
  { day: "Sun", entries: 356, users: 164 },
];

const trendingTopics: Topic[] = [
  { id: 1, title: "The last movie you watched that genuinely surprised you", entries: 847, score: 94.2, tags: ["film", "culture"], trend: "↑" },
  { id: 2, title: "Things software engineers say that are technically correct but annoying", entries: 1203, score: 91.7, tags: ["tech", "humor"], trend: "↑" },
  { id: 3, title: "Restaurants that deserve a Michelin star but will never get one", entries: 634, score: 88.4, tags: ["food", "local"], trend: "→" },
  { id: 4, title: "Books that changed how you see the world", entries: 2104, score: 86.1, tags: ["books", "life"], trend: "↑" },
  { id: 5, title: "Underrated keyboard shortcuts everyone should know", entries: 445, score: 81.3, tags: ["productivity", "tech"], trend: "↓" },
];

const recentEntries: Entry[] = [
  { id: 1, author: "kaleidoscope_mind", avatar: "K", topic: "The last movie you watched...", content: "Watched Caché by Haneke last night after years of avoiding it. The ending destroyed me. You keep waiting for resolution that never comes, and then you realise that IS the resolution.", time: "2m ago", votes: 34, isAnonymous: false, flagged: false },
  { id: 2, author: "Anonymous", avatar: "?", topic: "Things software engineers say...", content: '"It works on my machine" — delivered with the energy of someone presenting a theorem proof.', time: "7m ago", votes: 89, isAnonymous: true, flagged: false },
  { id: 3, author: "verdant_epoch", avatar: "V", topic: "Restaurants that deserve...", content: "A tiny family-run trattoria near Trastevere that doesn't take reservations, has handwritten menus, and makes the best cacio e pepe I've had outside someone's home kitchen.", time: "12m ago", votes: 12, isAnonymous: false, flagged: true },
  { id: 4, author: "hex_pilgrim", avatar: "H", topic: "Books that changed how you see...", content: "Gödel, Escher, Bach. Read it at 19. Still processing. Every few years I return to a chapter and find something new I missed entirely the first time.", time: "18m ago", votes: 67, isAnonymous: false, flagged: false },
];

const aiFlags: AIFlag[] = [
  { id: 1, type: "TOXICITY", confidence: 0.91, entry: "some comment about...", reviewed: false, time: "3m ago" },
  { id: 2, type: "SPAM", confidence: 0.87, entry: "check out my website...", reviewed: false, time: "15m ago" },
  { id: 3, type: "HATE_SPEECH", confidence: 0.76, entry: "a problematic statement...", reviewed: true, time: "1h ago" },
];

const plans: Plan[] = [
  { name: "Free", monthly: 0, tenants: 1847, revenue: 0, color: "#6b7280" },
  { name: "Premium", monthly: 29, tenants: 412, revenue: 11948, color: "#8b5cf6" },
  { name: "Enterprise", monthly: 199, tenants: 67, revenue: 13333, color: "#f59e0b" },
];

// ── Sub-components ─────────────────────────────────────────

type BadgeVariant = "default" | "purple" | "amber" | "red" | "green" | "blue";

function Badge({ children, variant = "default" }: { children: React.ReactNode; variant?: BadgeVariant }) {
  const colors: Record<BadgeVariant, string> = {
    default: "bg-zinc-800 text-zinc-300",
    purple: "bg-purple-900/50 text-purple-300 border border-purple-700/50",
    amber: "bg-amber-900/50 text-amber-300 border border-amber-700/50",
    red: "bg-red-900/50 text-red-300 border border-red-700/50",
    green: "bg-emerald-900/50 text-emerald-300 border border-emerald-700/50",
    blue: "bg-blue-900/50 text-blue-300 border border-blue-700/50",
  };
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${colors[variant]}`}>
      {children}
    </span>
  );
}

function StatCard({ label, value, sub, accent = "#8b5cf6" }: { label: string; value: string; sub?: string; accent?: string }) {
  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5 relative overflow-hidden">
      <div className="absolute inset-0 opacity-5" style={{ background: `radial-gradient(circle at top right, ${accent}, transparent 70%)` }} />
      <p className="text-zinc-500 text-xs font-medium uppercase tracking-widest mb-1">{label}</p>
      <p className="text-3xl font-bold text-white font-mono">{value}</p>
      {sub && <p className="text-zinc-500 text-xs mt-1">{sub}</p>}
    </div>
  );
}

function NavItem({ icon, label, active, onClick, badge }: { icon: string; label: string; active: boolean; onClick: () => void; badge?: number }) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all ${
        active
          ? "bg-violet-600/20 text-violet-300 border border-violet-600/30"
          : "text-zinc-500 hover:text-zinc-200 hover:bg-zinc-800/60"
      }`}
    >
      <span className="text-base">{icon}</span>
      <span className="flex-1 text-left font-medium">{label}</span>
      {badge && (
        <span className="bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center font-bold">
          {badge}
        </span>
      )}
    </button>
  );
}

// ── Views ──────────────────────────────────────────────────

function DashboardView() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Overview</h1>
          <p className="text-zinc-500 text-sm mt-0.5">Last 7 days across all communities</p>
        </div>
        <div className="flex gap-2">
          <button className="px-3 py-1.5 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-300 text-sm hover:bg-zinc-700 transition">7d</button>
          <button className="px-3 py-1.5 bg-zinc-800 border border-zinc-700 rounded-lg text-zinc-400 text-sm hover:bg-zinc-700 transition">30d</button>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Total Tenants" value="2,326" sub="+12 this week" accent="#8b5cf6" />
        <StatCard label="Active Users" value="48.2K" sub="↑ 18% vs last week" accent="#06b6d4" />
        <StatCard label="Entries Today" value="4,891" sub="across all communities" accent="#10b981" />
        <StatCard label="MRR" value="$25,281" sub="+$1,840 this month" accent="#f59e0b" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5">
          <p className="text-zinc-400 text-sm font-medium mb-4">Entry & User Activity</p>
          <ResponsiveContainer width="100%" height={180}>
            <AreaChart data={analyticsData}>
              <defs>
                <linearGradient id="gEntries" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="gUsers" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#06b6d4" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
              <XAxis dataKey="day" tick={{ fill: "#52525b", fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "#52525b", fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ background: "#18181b", border: "1px solid #3f3f46", borderRadius: 8, color: "#e4e4e7" }} />
              <Area type="monotone" dataKey="entries" stroke="#8b5cf6" strokeWidth={2} fill="url(#gEntries)" />
              <Area type="monotone" dataKey="users" stroke="#06b6d4" strokeWidth={2} fill="url(#gUsers)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5">
          <p className="text-zinc-400 text-sm font-medium mb-4">Revenue by Plan</p>
          <div className="space-y-3 mt-2">
            {plans.map(plan => (
              <div key={plan.name}>
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full" style={{ background: plan.color }} />
                    <span className="text-zinc-300 text-sm">{plan.name}</span>
                    <span className="text-zinc-600 text-xs">{plan.tenants} tenants</span>
                  </div>
                  <span className="text-white text-sm font-mono font-medium">${plan.revenue.toLocaleString()}</span>
                </div>
                <div className="h-1.5 bg-zinc-800 rounded-full overflow-hidden">
                  <div className="h-full rounded-full transition-all" style={{ width: `${(plan.revenue / 25281) * 100}%`, background: plan.color }} />
                </div>
              </div>
            ))}
          </div>
          <div className="mt-5 pt-4 border-t border-zinc-800 flex justify-between text-sm">
            <span className="text-zinc-500">Total MRR</span>
            <span className="text-white font-bold font-mono">$25,281</span>
          </div>
        </div>
      </div>

      <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5">
        <div className="flex items-center justify-between mb-4">
          <p className="text-zinc-400 text-sm font-medium">AI Moderation Queue</p>
          <Badge variant="red">{aiFlags.filter(f => !f.reviewed).length} pending</Badge>
        </div>
        <div className="space-y-2">
          {aiFlags.map(flag => (
            <div key={flag.id} className="flex items-center gap-4 p-3 rounded-lg bg-zinc-800/50 hover:bg-zinc-800 transition">
              <div className={`w-2 h-2 rounded-full ${flag.reviewed ? "bg-zinc-600" : "bg-red-500 animate-pulse"}`} />
              <Badge variant={flag.type === "TOXICITY" ? "red" : flag.type === "SPAM" ? "amber" : "red"}>{flag.type}</Badge>
              <span className="text-zinc-400 text-sm flex-1 truncate">&ldquo;{flag.entry}&rdquo;</span>
              <span className="text-zinc-600 text-xs font-mono">{(flag.confidence * 100).toFixed(0)}%</span>
              <span className="text-zinc-600 text-xs">{flag.time}</span>
              {!flag.reviewed && (
                <div className="flex gap-1">
                  <button className="px-2 py-1 bg-emerald-900/50 text-emerald-400 text-xs rounded hover:bg-emerald-900 transition">Allow</button>
                  <button className="px-2 py-1 bg-red-900/50 text-red-400 text-xs rounded hover:bg-red-900 transition">Remove</button>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function TopicsView({ onSelectTopic }: { onSelectTopic: (topic: Topic) => void }) {
  const [search, setSearch] = useState("");
  const filtered = trendingTopics.filter(t => t.title.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Trending Topics</h1>
          <p className="text-zinc-500 text-sm mt-0.5">Sorted by AI-computed trending score</p>
        </div>
        <button className="px-4 py-2 bg-violet-600 hover:bg-violet-500 text-white rounded-lg text-sm font-medium transition">+ New Topic</button>
      </div>
      <input
        value={search}
        onChange={e => setSearch(e.target.value)}
        placeholder="Search topics..."
        className="w-full bg-zinc-900 border border-zinc-800 rounded-lg px-4 py-2.5 text-white text-sm placeholder-zinc-600 focus:outline-none focus:border-violet-600 transition"
      />
      <div className="space-y-2">
        {filtered.map((topic, i) => (
          <div key={topic.id} onClick={() => onSelectTopic(topic)} className="group bg-zinc-900 border border-zinc-800 hover:border-zinc-700 rounded-xl p-4 cursor-pointer transition">
            <div className="flex items-start gap-4">
              <div className="text-zinc-700 font-mono text-lg font-bold w-6 text-right flex-shrink-0 mt-0.5">{i + 1}</div>
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-3">
                  <h3 className="text-zinc-100 font-medium group-hover:text-white transition leading-snug">{topic.title}</h3>
                  <div className="flex items-center gap-1.5 flex-shrink-0">
                    <span className="text-zinc-500 text-sm">{topic.trend}</span>
                    <div className="w-16 h-1.5 bg-zinc-800 rounded-full overflow-hidden">
                      <div className="h-full rounded-full bg-gradient-to-r from-violet-600 to-cyan-500" style={{ width: `${topic.score}%` }} />
                    </div>
                    <span className="text-xs font-mono text-zinc-400">{topic.score}</span>
                  </div>
                </div>
                <div className="flex items-center gap-3 mt-2">
                  {topic.tags.map(tag => <Badge key={tag} variant="default">#{tag}</Badge>)}
                  <span className="text-zinc-600 text-xs">{topic.entries.toLocaleString()} entries</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function TopicDetailView({ topic, onBack }: { topic: Topic; onBack: () => void }) {
  const [newEntry, setNewEntry] = useState("");
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [entries, setEntries] = useState<Entry[]>(recentEntries);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = () => {
    if (!newEntry.trim()) return;
    setSubmitting(true);
    setTimeout(() => {
      setEntries(prev => [{
        id: Date.now(), author: isAnonymous ? "Anonymous" : "you",
        avatar: isAnonymous ? "?" : "Y", topic: topic.title,
        content: newEntry, time: "just now", votes: 0, isAnonymous, flagged: false,
      }, ...prev]);
      setNewEntry("");
      setSubmitting(false);
    }, 600);
  };

  return (
    <div className="space-y-5">
      <button onClick={onBack} className="flex items-center gap-2 text-zinc-500 hover:text-zinc-300 text-sm transition">← Back to topics</button>
      <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-xl font-bold text-white leading-snug">{topic.title}</h1>
            <div className="flex items-center gap-3 mt-2">
              {topic.tags.map(tag => <Badge key={tag} variant="purple">#{tag}</Badge>)}
              <span className="text-zinc-600 text-xs">{topic.entries.toLocaleString()} entries</span>
            </div>
          </div>
          <Badge variant="amber">AI Summary</Badge>
        </div>
        <div className="mt-4 p-4 bg-zinc-800/50 border border-violet-900/30 rounded-lg">
          <p className="text-xs text-violet-400 font-medium mb-2">✦ AI-Generated Summary</p>
          <p className="text-zinc-300 text-sm leading-relaxed">
            This discussion showcases a wide variety of perspectives, from cult classics to mainstream blockbusters that subverted expectations. Users frequently cite foreign-language films and slow-burn psychological dramas as the most surprising.
          </p>
        </div>
      </div>
      <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4">
        <textarea value={newEntry} onChange={e => setNewEntry(e.target.value)} placeholder="Write your entry..." rows={3} className="w-full bg-transparent text-zinc-200 text-sm placeholder-zinc-700 resize-none focus:outline-none" />
        <div className="flex items-center justify-between pt-3 border-t border-zinc-800">
          <label className="flex items-center gap-2 cursor-pointer">
            <div onClick={() => setIsAnonymous(!isAnonymous)} className={`w-9 h-5 rounded-full transition-colors relative cursor-pointer ${isAnonymous ? "bg-violet-600" : "bg-zinc-700"}`}>
              <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-transform ${isAnonymous ? "translate-x-4" : "translate-x-0.5"}`} />
            </div>
            <span className="text-zinc-500 text-xs">Post anonymously</span>
            <Badge variant="purple">Premium</Badge>
          </label>
          <button onClick={handleSubmit} disabled={!newEntry.trim() || submitting} className="px-4 py-1.5 bg-violet-600 hover:bg-violet-500 disabled:opacity-50 disabled:cursor-not-allowed text-white text-sm rounded-lg transition font-medium">
            {submitting ? "Posting..." : "Post Entry"}
          </button>
        </div>
      </div>
      <div className="space-y-2">
        {entries.map(entry => (
          <div key={entry.id} className="bg-zinc-900 border border-zinc-800 rounded-xl p-4">
            <div className="flex items-start gap-3">
              <div className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold flex-shrink-0 ${entry.isAnonymous ? "bg-zinc-800 text-zinc-500" : "bg-violet-900/50 text-violet-300"}`}>{entry.avatar}</div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1.5">
                  <span className="text-zinc-400 text-xs font-medium">{entry.author}</span>
                  {entry.isAnonymous && <Badge variant="default">anon</Badge>}
                  {entry.flagged && <Badge variant="amber">⚑ flagged</Badge>}
                  <span className="text-zinc-700 text-xs">{entry.time}</span>
                </div>
                <p className="text-zinc-200 text-sm leading-relaxed">{entry.content}</p>
                <div className="flex items-center gap-3 mt-2.5">
                  <button className="flex items-center gap-1 text-zinc-600 hover:text-emerald-400 transition text-xs">▲ <span>{entry.votes}</span></button>
                  <button className="text-zinc-600 hover:text-red-400 transition text-xs">▼</button>
                  <button className="text-zinc-700 hover:text-zinc-400 transition text-xs">Reply</button>
                  <button className="text-zinc-700 hover:text-zinc-400 transition text-xs">Share</button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ModerationView() {
  const [tab, setTab] = useState("ai-queue");
  return (
    <div className="space-y-5">
      <h1 className="text-2xl font-bold text-white">Moderation</h1>
      <div className="flex gap-1 bg-zinc-900 border border-zinc-800 p-1 rounded-lg w-fit">
        {["ai-queue", "reports", "logs"].map(t => (
          <button key={t} onClick={() => setTab(t)} className={`px-4 py-1.5 rounded-md text-sm font-medium transition capitalize ${tab === t ? "bg-zinc-700 text-white" : "text-zinc-500 hover:text-zinc-300"}`}>
            {t.replace("-", " ")}
          </button>
        ))}
      </div>
      {tab === "ai-queue" && (
        <div className="space-y-2">
          {aiFlags.map(flag => (
            <div key={flag.id} className={`bg-zinc-900 border rounded-xl p-4 ${flag.reviewed ? "border-zinc-800 opacity-60" : "border-red-900/50"}`}>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Badge variant={flag.type === "TOXICITY" ? "red" : "amber"}>{flag.type}</Badge>
                  <span className="text-zinc-600 text-xs">Confidence: <span className="font-mono text-zinc-400">{(flag.confidence * 100).toFixed(0)}%</span></span>
                  <span className="text-zinc-700 text-xs">{flag.time}</span>
                </div>
                {flag.reviewed ? <Badge variant="green">Reviewed</Badge> : (
                  <div className="flex gap-2">
                    <button className="px-3 py-1 bg-emerald-900/50 border border-emerald-700/50 text-emerald-400 text-xs rounded-lg hover:bg-emerald-900 transition">Approve</button>
                    <button className="px-3 py-1 bg-red-900/50 border border-red-700/50 text-red-400 text-xs rounded-lg hover:bg-red-900 transition">Remove</button>
                    <button className="px-3 py-1 bg-zinc-800 text-zinc-400 text-xs rounded-lg hover:bg-zinc-700 transition">Warn User</button>
                  </div>
                )}
              </div>
              <p className="text-zinc-400 text-sm bg-zinc-800/50 rounded-lg p-3 font-mono">{flag.entry}</p>
            </div>
          ))}
        </div>
      )}
      {tab === "reports" && <div className="flex items-center justify-center h-32 text-zinc-600 text-sm">No open reports</div>}
      {tab === "logs" && (
        <div className="space-y-1">
          {["Entry hidden by AI (TOXICITY)", "User warned: spam", "Topic locked by admin", "Entry restored by moderator", "Anonymous identity revealed (legal request)"].map((log, i) => (
            <div key={i} className="flex items-center gap-4 py-2 px-3 rounded-lg hover:bg-zinc-900 transition text-sm">
              <span className="text-zinc-700 font-mono text-xs w-12">{i + 1}h ago</span>
              <span className="text-zinc-400">{log}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Main Export ────────────────────────────────────────────

export default function LexiconDashboard() {
  const [activeNav, setActiveNav] = useState("dashboard");
  const [selectedTopic, setSelectedTopic] = useState<Topic | null>(null);

  const nav = [
    { id: "dashboard", icon: "◈", label: "Dashboard" },
    { id: "topics", icon: "◇", label: "Topics" },
    { id: "moderation", icon: "⚑", label: "Moderation", badge: 2 },
    { id: "members", icon: "◉", label: "Members" },
    { id: "analytics", icon: "◌", label: "Analytics" },
    { id: "billing", icon: "◎", label: "Billing" },
    { id: "settings", icon: "◍", label: "Settings" },
  ];

  const handleSelectTopic = (topic: Topic) => { setSelectedTopic(topic); setActiveNav("topic-detail"); };

  const renderContent = () => {
    if (activeNav === "topic-detail" && selectedTopic) {
      return <TopicDetailView topic={selectedTopic} onBack={() => { setSelectedTopic(null); setActiveNav("topics"); }} />;
    }
    switch (activeNav) {
      case "dashboard": return <DashboardView />;
      case "topics": return <TopicsView onSelectTopic={handleSelectTopic} />;
      case "moderation": return <ModerationView />;
      default: return <div className="flex items-center justify-center h-64 text-zinc-700 text-sm">Section coming soon</div>;
    }
  };

  return (
    <div className="flex h-screen bg-black text-white overflow-hidden" style={{ fontFamily: "'DM Mono', 'JetBrains Mono', monospace" }}>
      <aside className="w-56 flex-shrink-0 bg-zinc-950 border-r border-zinc-900 flex flex-col">
        <div className="p-4 border-b border-zinc-900">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-violet-600 to-cyan-500 flex items-center justify-center text-xs font-bold">L</div>
            <div>
              <p className="text-white text-sm font-bold leading-none">LEXICON</p>
              <p className="text-zinc-600 text-xs">Admin Panel</p>
            </div>
          </div>
        </div>
        <div className="p-3">
          <button className="w-full flex items-center gap-2 px-3 py-2 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 rounded-lg transition">
            <div className="w-5 h-5 rounded bg-violet-600/30 flex items-center justify-center text-xs text-violet-400">P</div>
            <span className="text-zinc-300 text-xs flex-1 text-left truncate">philosophy.lexicon</span>
            <span className="text-zinc-600 text-xs">▾</span>
          </button>
        </div>
        <nav className="flex-1 p-2 space-y-0.5">
          {nav.map(item => (
            <NavItem key={item.id} {...item} active={activeNav === item.id || (activeNav === "topic-detail" && item.id === "topics")} onClick={() => { setActiveNav(item.id); setSelectedTopic(null); }} />
          ))}
        </nav>
        <div className="p-3 border-t border-zinc-900">
          <div className="flex items-center gap-2.5 px-2">
            <div className="w-7 h-7 rounded-full bg-gradient-to-br from-violet-500 to-pink-500 flex items-center justify-center text-xs font-bold">A</div>
            <div className="flex-1 min-w-0">
              <p className="text-zinc-300 text-xs font-medium truncate">admin@lexicon.app</p>
              <p className="text-zinc-600 text-xs">Super Admin</p>
            </div>
          </div>
        </div>
      </aside>
      <main className="flex-1 overflow-y-auto">
        <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-3 bg-black/80 backdrop-blur border-b border-zinc-900">
          <div className="flex items-center gap-2">
            <span className="text-zinc-700 text-sm">Lexicon</span>
            <span className="text-zinc-800">/</span>
            <span className="text-zinc-300 text-sm capitalize">
              {activeNav === "topic-detail" ? (selectedTopic?.title?.slice(0, 40) + "...") : activeNav}
            </span>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 text-xs text-emerald-400">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              All systems operational
            </div>
          </div>
        </div>
        <div className="p-6 max-w-5xl mx-auto">{renderContent()}</div>
      </main>
    </div>
  );
}
