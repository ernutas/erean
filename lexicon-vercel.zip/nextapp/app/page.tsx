import LexiconDashboard from "@/components/LexiconDashboard";

export default function Home() {
  return <LexiconDashboard />;
}
