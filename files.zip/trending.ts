// lib/algorithms/trending.ts
// AI-enhanced trending score algorithm for topics

import { prisma } from "@/lib/prisma";
import { redis } from "@/lib/redis";
import { openai } from "@/lib/openai";

// ============================================================
// TRENDING SCORE FORMULA
//
// score = (
//   entryVelocity * W_VELOCITY +
//   uniqueContributors * W_CONTRIBUTORS +
//   engagementRate * W_ENGAGEMENT +
//   sentimentWeight * W_SENTIMENT +
//   aiRelevanceScore * W_AI_RELEVANCE
// ) * recencyDecay
//
// recencyDecay = e^(-λ * hoursSinceLastEntry)
// ============================================================

const WEIGHTS = {
  VELOCITY: 0.35,       // Entry creation rate (entries/hour)
  CONTRIBUTORS: 0.20,   // Unique distinct author count
  ENGAGEMENT: 0.25,     // Votes / views ratio
  SENTIMENT: 0.10,      // Positive sentiment boost
  AI_RELEVANCE: 0.10,   // AI-determined importance/novelty
} as const;

const DECAY_LAMBDA = 0.05; // Controls how fast scores decay (~14h half-life)
const TRENDING_WINDOW_HOURS = 48; // Look back window for velocity calculation
const BATCH_SIZE = 100;

export interface TrendingScoreFactors {
  entryVelocity: number;       // entries per hour in window
  uniqueContributors: number;  // distinct authors in window (normalized 0-1)
  engagementRate: number;      // votes / max(views, 1) (0-1)
  recencyDecay: number;        // e^(-λ * hours) (0-1)
  sentimentScore: number;      // -1 to 1, normalized to 0-1
  aiRelevanceScore: number;    // 0-1 from AI evaluation
  finalScore: number;
}

export async function calculateTrendingScore(
  topicId: string,
  tenantId: string
): Promise<TrendingScoreFactors> {
  const windowStart = new Date(Date.now() - TRENDING_WINDOW_HOURS * 60 * 60 * 1000);

  // Fetch metrics in parallel
  const [topic, recentEntries, totalVotes] = await Promise.all([
    prisma.topic.findUnique({
      where: { id: topicId },
      select: {
        id: true,
        title: true,
        entryCount: true,
        viewCount: true,
        createdAt: true,
        updatedAt: true,
      },
    }),
    prisma.entry.findMany({
      where: {
        topicId,
        tenantId,
        isHidden: false,
        isDeleted: false,
        createdAt: { gte: windowStart },
      },
      select: {
        authorId: true,
        upvotes: true,
        downvotes: true,
        createdAt: true,
        aiModerationScore: true,
      },
      orderBy: { createdAt: "desc" },
    }),
    prisma.vote.count({
      where: {
        tenantId,
        entry: { topicId },
        createdAt: { gte: windowStart },
      },
    }),
  ]);

  if (!topic) {
    return zeroScore();
  }

  // 1. ENTRY VELOCITY — entries per hour in window
  const entryVelocity =
    recentEntries.length / Math.max(TRENDING_WINDOW_HOURS, 1);

  // 2. UNIQUE CONTRIBUTORS — normalized by sqrt to dampen superstar effect
  const uniqueAuthorIds = new Set(
    recentEntries.map((e) => e.authorId).filter(Boolean)
  );
  const rawContributors = uniqueAuthorIds.size;
  const uniqueContributors = normalizeLog(rawContributors, 1, 200);

  // 3. ENGAGEMENT RATE — (upvotes + votes) / views
  const totalVotesInWindow = recentEntries.reduce(
    (sum, e) => sum + e.upvotes + e.downvotes,
    0
  );
  const engagementRate = Math.min(
    totalVotesInWindow / Math.max(topic.viewCount, 1),
    1
  );

  // 4. RECENCY DECAY — based on hours since last entry
  const lastEntry = recentEntries[0];
  const hoursSinceLastEntry = lastEntry
    ? (Date.now() - lastEntry.createdAt.getTime()) / (1000 * 60 * 60)
    : TRENDING_WINDOW_HOURS;
  const recencyDecay = Math.exp(-DECAY_LAMBDA * hoursSinceLastEntry);

  // 5. SENTIMENT SCORE — weighted avg of ai moderation scores
  // Lower moderation score = more positive/safe content = boost
  const avgModerationRisk =
    recentEntries.length > 0
      ? recentEntries.reduce((sum, e) => sum + (e.aiModerationScore ?? 0.1), 0) /
        recentEntries.length
      : 0.1;
  const sentimentScore = 1 - avgModerationRisk; // Invert: low risk = high sentiment

  // 6. AI RELEVANCE SCORE — fetch or compute
  const aiRelevanceScore = await getAIRelevanceScore(
    topicId,
    tenantId,
    topic.title,
    recentEntries.length
  );

  // FINAL WEIGHTED SCORE
  const rawScore =
    entryVelocity * WEIGHTS.VELOCITY +
    uniqueContributors * WEIGHTS.CONTRIBUTORS +
    engagementRate * WEIGHTS.ENGAGEMENT +
    sentimentScore * WEIGHTS.SENTIMENT +
    aiRelevanceScore * WEIGHTS.AI_RELEVANCE;

  const finalScore = rawScore * recencyDecay * 100; // Scale to 0-100

  return {
    entryVelocity,
    uniqueContributors,
    engagementRate,
    recencyDecay,
    sentimentScore,
    aiRelevanceScore,
    finalScore,
  };
}

// ============================================================
// AI RELEVANCE SCORE
// Cached per topic, refreshed every 6 hours
// ============================================================

async function getAIRelevanceScore(
  topicId: string,
  tenantId: string,
  title: string,
  recentEntryCount: number
): Promise<number> {
  const cacheKey = `ai:relevance:${topicId}`;
  const cached = await redis.get(cacheKey);
  if (cached) return parseFloat(cached);

  // If no recent activity, skip AI call and return neutral
  if (recentEntryCount < 3) {
    await redis.setex(cacheKey, 1800, "0.3");
    return 0.3;
  }

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content:
            "You are a content relevance scoring engine. Score the given topic title for trending relevance on a scale of 0.0 to 1.0. Consider novelty, cultural relevance, timeliness, and discussion potential. Respond ONLY with a JSON object: {\"score\": <number>, \"reason\": \"<brief reason>\"}",
        },
        {
          role: "user",
          content: `Topic: "${title}"\nRecent entries in 48h: ${recentEntryCount}\nScore this topic's trending relevance.`,
        },
      ],
      max_tokens: 100,
      temperature: 0.3,
    });

    const content = response.choices[0].message.content || "{}";
    const parsed = JSON.parse(content);
    const score = Math.max(0, Math.min(1, parseFloat(parsed.score) || 0.3));

    await redis.setex(cacheKey, 21600, score.toString()); // Cache 6h
    return score;
  } catch {
    await redis.setex(cacheKey, 300, "0.3");
    return 0.3;
  }
}

// ============================================================
// BATCH TRENDING UPDATE JOB
// Called by background worker every 15 minutes
// ============================================================

export async function updateTrendingScores(tenantId: string): Promise<void> {
  let cursor: string | undefined;

  do {
    const topics = await prisma.topic.findMany({
      where: {
        tenantId,
        isArchived: false,
        isLocked: false,
        updatedAt: {
          gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // Active in last 7 days
        },
      },
      select: { id: true },
      take: BATCH_SIZE,
      skip: cursor ? 1 : 0,
      cursor: cursor ? { id: cursor } : undefined,
      orderBy: { id: "asc" },
    });

    if (topics.length === 0) break;

    // Calculate scores in parallel (rate-limited batches)
    const updates = await Promise.allSettled(
      topics.map(async (topic) => {
        const factors = await calculateTrendingScore(topic.id, tenantId);
        return { id: topic.id, factors };
      })
    );

    // Batch update scores
    await prisma.$transaction(
      updates
        .filter(
          (r): r is PromiseFulfilledResult<{ id: string; factors: TrendingScoreFactors }> =>
            r.status === "fulfilled"
        )
        .map(({ value }) =>
          prisma.topic.update({
            where: { id: value.id },
            data: { trendingScore: value.factors.finalScore },
          })
        )
    );

    // Snapshot for analytics
    const snapshots = updates
      .filter(
        (r): r is PromiseFulfilledResult<{ id: string; factors: TrendingScoreFactors }> =>
          r.status === "fulfilled"
      )
      .map(({ value }) => ({
        topicId: value.id,
        tenantId,
        score: value.factors.finalScore,
        rank: 0, // Set after ranking
        entryVelocity: value.factors.entryVelocity,
        uniqueContributors: 0,
        engagementRate: value.factors.engagementRate,
        sentimentScore: value.factors.sentimentScore,
        aiRelevanceScore: value.factors.aiRelevanceScore,
      }));

    await prisma.trendingSnapshot.createMany({ data: snapshots });

    cursor = topics[topics.length - 1].id;
    if (topics.length < BATCH_SIZE) break;
  } while (true);

  // Assign ranks
  await assignTrendingRanks(tenantId);
}

async function assignTrendingRanks(tenantId: string): Promise<void> {
  const topics = await prisma.topic.findMany({
    where: { tenantId, isArchived: false },
    select: { id: true, trendingScore: true },
    orderBy: { trendingScore: "desc" },
    take: 1000,
  });

  await prisma.$transaction(
    topics.map((topic, index) =>
      prisma.topic.update({
        where: { id: topic.id },
        data: { trendingRank: index + 1 },
      })
    )
  );
}

// ============================================================
// HELPERS
// ============================================================

function normalizeLog(value: number, min: number, max: number): number {
  if (value <= min) return 0;
  if (value >= max) return 1;
  return Math.log(value - min + 1) / Math.log(max - min + 1);
}

function zeroScore(): TrendingScoreFactors {
  return {
    entryVelocity: 0,
    uniqueContributors: 0,
    engagementRate: 0,
    recencyDecay: 0,
    sentimentScore: 0,
    aiRelevanceScore: 0,
    finalScore: 0,
  };
}
