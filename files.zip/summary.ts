// lib/ai/summary.ts
// AI topic summary generation — premium feature

import { openai } from "@/lib/openai";
import { prisma } from "@/lib/prisma";
import { redis } from "@/lib/redis";

const MIN_ENTRIES_FOR_SUMMARY = 10;
const REGEN_THRESHOLD = 0.3; // Regenerate if 30% more entries since last summary

// ============================================================
// GENERATE / REFRESH TOPIC SUMMARY
// ============================================================

export async function generateTopicSummary(
  topicId: string,
  tenantId: string,
  force = false
): Promise<string | null> {
  const topic = await prisma.topic.findUnique({
    where: { id: topicId, tenantId },
    select: {
      id: true,
      title: true,
      description: true,
      entryCount: true,
      aiSummary: true,
      aiSummaryAt: true,
      aiSummaryVersion: true,
    },
  });

  if (!topic) return null;
  if (topic.entryCount < MIN_ENTRIES_FOR_SUMMARY && !force) return null;

  // Check if regeneration is needed
  if (!force && topic.aiSummary && topic.aiSummaryAt) {
    const summaryEntryCount = await getSummaryEntryCount(topicId);
    const growthRatio =
      (topic.entryCount - summaryEntryCount) / Math.max(summaryEntryCount, 1);

    if (growthRatio < REGEN_THRESHOLD) {
      return topic.aiSummary; // No regeneration needed
    }
  }

  // Fetch recent entries for context
  const entries = await prisma.entry.findMany({
    where: {
      topicId,
      tenantId,
      isHidden: false,
      isDeleted: false,
    },
    select: {
      content: true,
      upvotes: true,
      score: true,
      createdAt: true,
    },
    orderBy: [
      { score: "desc" },
      { createdAt: "desc" },
    ],
    take: 50, // Top 50 entries for context window management
  });

  if (entries.length < MIN_ENTRIES_FOR_SUMMARY) return null;

  // Build prompt context
  const entryContext = entries
    .map((e, i) => `[${i + 1}] ${e.content.slice(0, 500)}`)
    .join("\n\n");

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are an expert community discussion analyst. Generate an insightful, neutral summary of the discussion entries for a topic in a collaborative knowledge platform. 

Your summary should:
- Capture the main perspectives and key points discussed
- Highlight areas of consensus and disagreement  
- Note any notable insights or conclusions
- Be informative but concise (3-4 paragraphs)
- Use neutral, encyclopedic language
- NOT include personal opinions or editorialization

Format as flowing prose paragraphs, not bullet points.`,
        },
        {
          role: "user",
          content: `Topic: "${topic.title}"
${topic.description ? `Description: ${topic.description}\n` : ""}
Number of entries: ${topic.entryCount}

Top entries (by score):
${entryContext}

Generate a comprehensive summary of this discussion.`,
        },
      ],
      max_tokens: 800,
      temperature: 0.3,
    });

    const summary = response.choices[0].message.content || "";
    const tokens = response.usage?.total_tokens || 0;
    const newVersion = topic.aiSummaryVersion + 1;

    // Save summary history + update topic
    await prisma.$transaction([
      prisma.topicSummary.create({
        data: {
          topicId,
          tenantId,
          summary,
          model: "gpt-4o",
          entryCountAt: topic.entryCount,
          version: newVersion,
          tokens,
        },
      }),
      prisma.topic.update({
        where: { id: topicId },
        data: {
          aiSummary: summary,
          aiSummaryAt: new Date(),
          aiSummaryVersion: newVersion,
        },
      }),
    ]);

    // Cache summary
    await redis.setex(`summary:${topicId}`, 3600, summary);

    return summary;
  } catch (error) {
    console.error("[AI Summary] Error generating summary:", error);
    return null;
  }
}

// ============================================================
// AUTO-TAG GENERATION
// ============================================================

export interface AutoTagResult {
  tags: { name: string; confidence: number }[];
  model: string;
}

export async function generateAutoTags(
  title: string,
  description: string | null,
  tenantId: string,
  existingTagNames: string[]
): Promise<AutoTagResult> {
  const cacheKey = `autotag:${Buffer.from(title).toString("base64").slice(0, 32)}`;
  const cached = await redis.get(cacheKey);
  if (cached) {
    return JSON.parse(cached) as AutoTagResult;
  }

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        {
          role: "system",
          content: `You are a content tagging system for a knowledge community platform. Generate relevant tags for topics.

Return ONLY a JSON object:
{
  "tags": [
    { "name": "tag-name", "confidence": 0.9 },
    ...
  ]
}

Rules:
- 3-7 tags maximum
- Lowercase, hyphenated (e.g., "machine-learning", "pop-culture")
- Confidence 0.5-1.0
- Focus on categories, themes, and key concepts
- Don't generate redundant tags
- Existing tags to possibly reuse: ${existingTagNames.slice(0, 20).join(", ")}`,
        },
        {
          role: "user",
          content: `Topic title: "${title}"${description ? `\nDescription: "${description}"` : ""}`,
        },
      ],
      max_tokens: 300,
      temperature: 0.2,
      response_format: { type: "json_object" },
    });

    const raw = response.choices[0].message.content || '{"tags":[]}';
    const parsed = JSON.parse(raw);
    const result: AutoTagResult = {
      tags: parsed.tags || [],
      model: "gpt-4o-mini",
    };

    await redis.setex(cacheKey, 86400, JSON.stringify(result));
    return result;
  } catch (error) {
    console.error("[AI Auto-tag] Error:", error);
    return { tags: [], model: "gpt-4o-mini" };
  }
}

// ============================================================
// TOPIC SUMMARY QUEUE (Background Job)
// ============================================================

export async function queueSummaryGeneration(
  topicId: string,
  tenantId: string
): Promise<void> {
  const queueKey = `queue:summary:${tenantId}`;
  const job = JSON.stringify({ topicId, tenantId, at: Date.now() });

  await redis.lpush(queueKey, job);

  // Set TTL on queue key if not set
  const ttl = await redis.ttl(queueKey);
  if (ttl < 0) {
    await redis.expire(queueKey, 86400);
  }
}

// Worker: Process summary queue (run by background worker process)
export async function processSummaryQueue(tenantId: string): Promise<void> {
  const queueKey = `queue:summary:${tenantId}`;

  while (true) {
    const item = await redis.rpop(queueKey);
    if (!item) break;

    try {
      const { topicId } = JSON.parse(item);
      await generateTopicSummary(topicId, tenantId);
    } catch (error) {
      console.error("[Summary Worker] Error processing job:", error);
    }

    // Rate limit
    await new Promise((r) => setTimeout(r, 500));
  }
}

// ============================================================
// HELPERS
// ============================================================

async function getSummaryEntryCount(topicId: string): Promise<number> {
  const summary = await prisma.topicSummary.findFirst({
    where: { topicId },
    orderBy: { createdAt: "desc" },
    select: { entryCountAt: true },
  });
  return summary?.entryCountAt ?? 0;
}
