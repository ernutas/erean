# LEXICON PLATFORM — Architecture & Deployment Guide
## Enterprise Multi-Tenant AI-Powered Discussion Platform

---

## 1. ARCHITECTURE OVERVIEW

### System Topology

```
                        ┌─────────────────────────────────┐
                        │        Cloudflare CDN           │
                        │   (DDoS, WAF, Asset Caching)    │
                        └──────────────┬──────────────────┘
                                       │
                        ┌─────────────▼──────────────────┐
                        │         Nginx (Reverse Proxy)   │
                        │   Multi-tenant domain routing   │
                        └──┬──────────────────────┬───────┘
                           │                      │
              ┌────────────▼──┐           ┌───────▼──────────┐
              │  Next.js App  │           │   WS Server      │
              │  (App Router) │           │  (ws + Redis PS)  │
              │  Horizontal   │           │  Horizontal       │
              └──────┬────────┘           └───────┬──────────┘
                     │                            │
        ┌────────────▼──────────────┬─────────────▼──────────┐
        │       PostgreSQL          │          Redis          │
        │    (Primary + Replica)    │  (Cache + PubSub + RL)  │
        └───────────────────────────┴────────────────────────┘
                                       │
                          ┌────────────▼───────────┐
                          │   Background Worker     │
                          │  Trending + Summaries   │
                          │  Moderation Queue       │
                          └────────────────────────┘
```

### Multi-Tenant Request Flow

```
1. Request arrives at Nginx
2. Nginx forwards to Next.js with Host header
3. Edge Middleware (middleware.ts) extracts tenant context:
   - Custom domain → DB/Redis lookup by domain
   - *.lexicon.app → DB/Redis lookup by subdomain  
   - admin.lexicon.app → Super Admin routing
4. Tenant context injected as request headers (x-tenant-id, etc.)
5. App Router reads tenant via React cache() — single DB call/request
6. All DB queries include tenantId in WHERE clause
```

---

## 2. FOLDER STRUCTURE

```
lexicon-platform/
├── app/                          # Next.js App Router
│   ├── (platform)/               # Platform-level routes (lexicon.app)
│   │   ├── page.tsx              # Landing page
│   │   ├── pricing/page.tsx
│   │   └── auth/
│   ├── (tenant)/                 # Tenant-scoped routes
│   │   ├── layout.tsx            # Loads tenant branding
│   │   ├── page.tsx              # Community home / trending
│   │   ├── topics/
│   │   │   ├── page.tsx          # Topic list
│   │   │   └── [slug]/page.tsx   # Topic detail + entries
│   │   └── profile/[username]/
│   ├── (admin)/                  # Tenant admin routes
│   │   ├── admin/layout.tsx
│   │   ├── admin/dashboard/
│   │   ├── admin/moderation/
│   │   ├── admin/members/
│   │   └── admin/settings/
│   ├── (super-admin)/            # Platform super admin
│   │   └── __admin/
│   │       ├── tenants/
│   │       ├── revenue/
│   │       └── ai-flags/
│   └── api/
│       ├── entries/route.ts
│       ├── topics/route.ts
│       ├── votes/route.ts
│       ├── notifications/route.ts
│       ├── admin/
│       │   ├── tenants/
│       │   └── moderation/
│       └── webhooks/
│           ├── stripe/route.ts
│           └── ai/route.ts
│
├── lib/
│   ├── ai/
│   │   ├── moderation.ts         # AI toxicity/spam detection
│   │   ├── summary.ts            # Topic summary + auto-tagging
│   │   └── trending.ts           # AI relevance scoring
│   ├── algorithms/
│   │   └── trending.ts           # Full trending score algorithm
│   ├── auth/
│   │   ├── session.ts            # Auth helper
│   │   └── config.ts             # NextAuth config
│   ├── stripe/
│   │   └── index.ts              # Stripe integration
│   ├── tenant/
│   │   └── resolver.ts           # Tenant resolution + caching
│   ├── websockets/
│   │   └── index.ts              # WS server + Redis pub/sub
│   ├── audit.ts                  # Immutable audit logging
│   ├── openai.ts                 # OpenAI client singleton
│   ├── prisma.ts                 # Prisma client singleton
│   ├── rate-limit.ts             # Redis sliding window RL
│   └── redis.ts                  # Redis client singleton
│
├── components/
│   ├── ui/                       # shadcn/ui components
│   ├── admin/                    # Admin dashboard components
│   ├── community/                # Tenant-facing components
│   │   ├── EntryCard.tsx
│   │   ├── TopicList.tsx
│   │   ├── TrendingBar.tsx
│   │   └── AISummaryBlock.tsx
│   └── shared/
│
├── prisma/
│   └── schema.prisma
│
├── workers/
│   ├── trending.worker.ts        # Updates trending scores every 15m
│   ├── summary.worker.ts         # Processes AI summary queue
│   └── index.ts                  # Worker orchestrator
│
├── i18n/
│   ├── en/common.json
│   ├── tr/common.json
│   └── config.ts
│
├── middleware.ts                 # Multi-tenant routing
├── docker-compose.yml
├── Dockerfile
├── Dockerfile.worker
└── .env.example
```

---

## 3. DATABASE ISOLATION STRATEGY

### Row-Level Security Approach
Every table that belongs to a tenant includes a `tenantId` column. All application-level queries MUST include `tenantId` in WHERE clauses:

```typescript
// ✅ Correct — always scoped to tenant
const entries = await prisma.entry.findMany({
  where: { topicId, tenantId: tenant.id }
});

// ❌ Wrong — cross-tenant data leak
const entries = await prisma.entry.findMany({
  where: { topicId }
});
```

### PostgreSQL Row-Level Security (Optional Enhancement)
For an additional defense layer, enable Postgres RLS:
```sql
ALTER TABLE entries ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON entries
  USING (tenant_id = current_setting('app.tenant_id')::uuid);
```

Set at connection time:
```typescript
await prisma.$executeRaw`SET app.tenant_id = ${tenantId}`;
```

### Indexing Strategy
All indexes are composite, tenant-first:
- `(tenantId, topicId, createdAt DESC)` — entry feeds
- `(tenantId, trendingScore DESC)` — trending homepage
- `(tenantId, status)` — moderation queue filters
- `(tenantId, isRead)` — notification counts

---

## 4. ANONYMOUS MODE DESIGN

```
User posts anonymously:
1. Entry.authorId = NULL
2. Entry.isAnonymous = TRUE
3. AnonymousEntry record created:
   - entryId → Entry
   - actualUserId → User (real identity stored securely)
   - ipAddress, userAgent logged
4. API layer returns author as NULL to all non-moderators
5. Moderators can see a "reveal identity" button
6. Reveal action:
   - Requires OWNER or ADMIN role
   - Creates AuditLog (immutable)
   - Sets AnonymousEntry.revealedAt, revealedBy
   - Returns actualUser info
```

Audit logs are append-only — no UPDATE or DELETE is permitted on the `audit_logs` table in production:
```sql
REVOKE UPDATE, DELETE ON audit_logs FROM lexicon;
```

---

## 5. AI TRENDING ALGORITHM

```
score = (
  entryVelocity    × 0.35  +   // entries/hour in 48h window
  uniqueContrib    × 0.20  +   // log-normalized distinct authors
  engagementRate   × 0.25  +   // votes / max(views, 1)
  sentimentScore   × 0.10  +   // 1 - avg_moderation_risk
  aiRelevance      × 0.10      // GPT-4o-mini relevance score
) × e^(-0.05 × hoursSinceLastEntry)

Recency half-life ≈ 14 hours
AI relevance cached 6 hours per topic
Scores updated every 15 minutes by background worker
Top 1000 topics ranked and stored in trendingRank column
```

---

## 6. SUBSCRIPTION FEATURE GATES

| Feature                 | Free | Premium | Enterprise |
|------------------------|------|---------|------------|
| Topics / Topics        | ∞    | ∞       | ∞          |
| Entries/day per user   | 10   | 50      | Unlimited  |
| Anonymous posting      | ✗    | ✓       | ✓          |
| AI Topic Summary       | ✗    | ✓       | ✓          |
| Advanced analytics     | ✗    | ✓       | ✓          |
| Custom profile themes  | ✗    | ✓       | ✓          |
| API access             | ✗    | ✗       | ✓          |
| White-label / custom domain | ✗ | ✓    | ✓          |
| SLA                    | —    | 99.9%   | 99.99%     |

---

## 7. SECURITY CHECKLIST

- [x] CSRF: SameSite=Strict cookies + origin validation on API
- [x] XSS: DOMPurify sanitization on all user content
- [x] SQL Injection: Prisma parameterized queries (no raw SQL with user input)
- [x] Rate Limiting: Redis sliding window per endpoint
- [x] Webhook Signature: Stripe signature verification (constructEvent)
- [x] Role Guards: Middleware checks on all admin routes
- [x] Tenant Isolation: tenantId on every query
- [x] Audit Logs: Immutable append-only log for sensitive actions
- [x] Anonymous: Real identity never exposed without authorization
- [x] Zod: All API inputs validated with Zod schemas
- [x] HttpOnly Cookies: Sessions stored in httpOnly, Secure, SameSite=Strict cookies
- [x] Content Security Policy: Configured in Next.js headers

---

## 8. DEPLOYMENT GUIDE

### Prerequisites
- Docker + Docker Compose
- Domain with wildcard DNS: `*.lexicon.app → your-server-ip`
- Stripe account with products and prices configured
- OpenAI API key

### Quick Start (Development)
```bash
git clone https://github.com/your-org/lexicon-platform
cd lexicon-platform
cp .env.example .env
# Fill in .env values

docker-compose up -d postgres redis
npx prisma migrate dev
npx prisma db seed
npm run dev
```

### Production Deployment
```bash
# Build and start all services
docker-compose -f docker-compose.yml -f docker-compose.prod.yml up -d

# Run migrations
docker-compose exec app npx prisma migrate deploy

# Check health
curl https://lexicon.app/api/health
```

### Scaling Strategy

**Horizontal App Scaling:**
- Deploy multiple app containers behind load balancer
- Redis handles session sharing, pub/sub, rate limits
- No sticky sessions needed

**Database Scaling:**
- Read replica for analytics queries
- Connection pooling via PgBouncer
- Prisma datasource reads from replica for reads

**WebSocket Scaling:**
- Multiple WS server instances
- Redis pub/sub broadcasts across all instances
- Each instance handles its own connections pool

### Background Workers
```bash
# Worker runs trending + summary generation
docker-compose exec worker node -r tsx/register workers/index.ts

# Cron schedule (example):
# */15 * * * * trending update (all active tenants)
# 0 * * * *   summary queue flush
# 0 2 * * *   cleanup old notifications
```

### Environment Variables Summary
See `.env.example` for the complete list. Critical variables:
- `DATABASE_URL` — PostgreSQL connection string
- `REDIS_URL` — Redis connection string
- `NEXTAUTH_SECRET` — min 32 random characters
- `STRIPE_SECRET_KEY` + `STRIPE_WEBHOOK_SECRET`
- `OPENAI_API_KEY`
- `NEXT_PUBLIC_PLATFORM_DOMAIN`

---

## 9. CI/CD OUTLINE

```yaml
# GitHub Actions
on: [push to main]

jobs:
  test:
    - npm ci
    - npx prisma generate
    - npm run type-check
    - npm run test

  build:
    - docker build (with build args)
    - push to registry

  deploy:
    - SSH to server
    - docker-compose pull
    - docker-compose up -d --no-deps app worker
    - docker-compose exec app npx prisma migrate deploy
    - health check
```

---

## 10. TECH STACK SUMMARY

| Layer           | Technology                                |
|----------------|-------------------------------------------|
| Framework       | Next.js 14 App Router + TypeScript        |
| Styling         | TailwindCSS + shadcn/ui                   |
| Animation       | Framer Motion                             |
| Database        | PostgreSQL 16                             |
| ORM             | Prisma 5                                  |
| Caching         | Redis 7 (cache + pub/sub + rate limiting) |
| Auth            | NextAuth.js v5                            |
| Payments        | Stripe (subscriptions + webhooks)         |
| AI              | OpenAI gpt-4o + gpt-4o-mini + moderation  |
| Real-time       | WebSockets (ws) + Redis pub/sub           |
| i18n            | next-intl                                 |
| Validation      | Zod                                       |
| Content Safety  | DOMPurify + marked                        |
| Infrastructure  | Docker + Nginx + GitHub Actions           |
| Charts          | Recharts                                  |
