// lib/stripe/index.ts
// Stripe subscription management

import Stripe from "stripe";
import { prisma } from "@/lib/prisma";
import { invalidateTenantCache } from "@/lib/tenant/resolver";
import type { SubscriptionStatus } from "@prisma/client";

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2024-06-20",
  typescript: true,
});

// ============================================================
// SUBSCRIPTION MANAGEMENT
// ============================================================

export async function createOrRetrieveStripeCustomer(
  tenantId: string,
  email: string,
  name: string
): Promise<string> {
  const tenant = await prisma.tenant.findUnique({
    where: { id: tenantId },
    select: { stripeCustomerId: true },
  });

  if (tenant?.stripeCustomerId) {
    return tenant.stripeCustomerId;
  }

  const customer = await stripe.customers.create({
    email,
    name,
    metadata: { tenantId },
  });

  await prisma.tenant.update({
    where: { id: tenantId },
    data: { stripeCustomerId: customer.id },
  });

  return customer.id;
}

export async function createCheckoutSession(
  tenantId: string,
  planId: string,
  successUrl: string,
  cancelUrl: string,
  userId: string
): Promise<Stripe.Checkout.Session> {
  const [tenant, plan] = await Promise.all([
    prisma.tenant.findUniqueOrThrow({
      where: { id: tenantId },
      select: { name: true, stripeCustomerId: true },
    }),
    prisma.plan.findUniqueOrThrow({
      where: { id: planId },
      select: { stripePriceId: true, name: true },
    }),
  ]);

  const customerId = tenant.stripeCustomerId;
  if (!customerId) throw new Error("Stripe customer not initialized");
  if (!plan.stripePriceId) throw new Error("Plan has no Stripe price");

  const session = await stripe.checkout.sessions.create({
    customer: customerId,
    mode: "subscription",
    payment_method_types: ["card"],
    line_items: [{ price: plan.stripePriceId, quantity: 1 }],
    success_url: successUrl,
    cancel_url: cancelUrl,
    subscription_data: {
      metadata: { tenantId, planId, userId },
      trial_period_days: 14,
    },
    metadata: { tenantId, planId, userId },
    allow_promotion_codes: true,
  });

  return session;
}

export async function createBillingPortalSession(
  tenantId: string,
  returnUrl: string
): Promise<Stripe.BillingPortal.Session> {
  const tenant = await prisma.tenant.findUniqueOrThrow({
    where: { id: tenantId },
    select: { stripeCustomerId: true },
  });

  if (!tenant.stripeCustomerId) {
    throw new Error("No Stripe customer found for tenant");
  }

  return stripe.billingPortal.sessions.create({
    customer: tenant.stripeCustomerId,
    return_url: returnUrl,
  });
}

// ============================================================
// WEBHOOK HANDLER
// ============================================================

export async function handleStripeWebhook(
  payload: string,
  signature: string
): Promise<void> {
  let event: Stripe.Event;

  try {
    event = stripe.webhooks.constructEvent(
      payload,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET!
    );
  } catch (err) {
    throw new Error(`Webhook signature verification failed: ${err}`);
  }

  // Idempotency check
  const existing = await prisma.webhookEvent.findUnique({
    where: { eventId: event.id },
  });
  if (existing?.processed) return;

  // Upsert event record
  await prisma.webhookEvent.upsert({
    where: { eventId: event.id },
    create: {
      eventId: event.id,
      provider: "stripe",
      eventType: event.type,
      payload: event as object,
      processed: false,
    },
    update: { attempts: { increment: 1 } },
  });

  try {
    await routeStripeEvent(event);

    await prisma.webhookEvent.update({
      where: { eventId: event.id },
      data: { processed: true, processedAt: new Date() },
    });
  } catch (error) {
    await prisma.webhookEvent.update({
      where: { eventId: event.id },
      data: { error: String(error) },
    });
    throw error;
  }
}

async function routeStripeEvent(event: Stripe.Event): Promise<void> {
  switch (event.type) {
    case "customer.subscription.created":
    case "customer.subscription.updated":
      await syncSubscription(event.data.object as Stripe.Subscription);
      break;

    case "customer.subscription.deleted":
      await handleSubscriptionDeleted(event.data.object as Stripe.Subscription);
      break;

    case "invoice.paid":
      await handleInvoicePaid(event.data.object as Stripe.Invoice);
      break;

    case "invoice.payment_failed":
      await handlePaymentFailed(event.data.object as Stripe.Invoice);
      break;

    case "checkout.session.completed":
      await handleCheckoutCompleted(
        event.data.object as Stripe.Checkout.Session
      );
      break;

    default:
      // Unhandled — just log
      console.log(`[Stripe Webhook] Unhandled event type: ${event.type}`);
  }
}

// ============================================================
// SUBSCRIPTION SYNC
// ============================================================

async function syncSubscription(subscription: Stripe.Subscription): Promise<void> {
  const tenantId = subscription.metadata?.tenantId;
  const planId = subscription.metadata?.planId;

  if (!tenantId) {
    console.warn("[Stripe] Missing tenantId in subscription metadata");
    return;
  }

  const status = mapStripeStatus(subscription.status);

  await prisma.tenant.update({
    where: { id: tenantId },
    data: {
      stripeSubscriptionId: subscription.id,
      subscriptionStatus: status,
      subscriptionEndsAt:
        subscription.current_period_end
          ? new Date(subscription.current_period_end * 1000)
          : null,
      planId: planId ?? undefined,
    },
  });

  await invalidateTenantCache({ id: tenantId });
}

async function handleSubscriptionDeleted(
  subscription: Stripe.Subscription
): Promise<void> {
  const tenantId = subscription.metadata?.tenantId;
  if (!tenantId) return;

  const freePlan = await prisma.plan.findFirst({
    where: { slug: "free" },
    select: { id: true },
  });

  await prisma.tenant.update({
    where: { id: tenantId },
    data: {
      stripeSubscriptionId: null,
      subscriptionStatus: "FREE",
      subscriptionEndsAt: null,
      planId: freePlan?.id ?? null,
    },
  });

  await invalidateTenantCache({ id: tenantId });
}

async function handleInvoicePaid(invoice: Stripe.Invoice): Promise<void> {
  if (!invoice.customer) return;

  const tenant = await prisma.tenant.findFirst({
    where: { stripeCustomerId: invoice.customer as string },
    select: { id: true },
  });

  if (!tenant) return;

  await prisma.invoice.create({
    data: {
      tenantId: tenant.id,
      stripeInvoiceId: invoice.id,
      amount: (invoice.amount_paid / 100) as unknown as Parameters<typeof prisma.invoice.create>[0]["data"]["amount"],
      currency: invoice.currency,
      status: "PAID",
      paidAt: invoice.status_transitions?.paid_at
        ? new Date(invoice.status_transitions.paid_at * 1000)
        : new Date(),
      hostedInvoiceUrl: invoice.hosted_invoice_url ?? null,
      invoicePdf: invoice.invoice_pdf ?? null,
    },
  });
}

async function handlePaymentFailed(invoice: Stripe.Invoice): Promise<void> {
  if (!invoice.customer) return;

  const tenant = await prisma.tenant.findFirst({
    where: { stripeCustomerId: invoice.customer as string },
    select: { id: true },
  });

  if (!tenant) return;

  await prisma.tenant.update({
    where: { id: tenant.id },
    data: { subscriptionStatus: "PAST_DUE" },
  });

  await invalidateTenantCache({ id: tenant.id });
}

async function handleCheckoutCompleted(
  session: Stripe.Checkout.Session
): Promise<void> {
  if (session.subscription) {
    const subscription = await stripe.subscriptions.retrieve(
      session.subscription as string
    );
    await syncSubscription(subscription);
  }
}

// ============================================================
// FEATURE GATING
// ============================================================

export async function checkFeatureAccess(
  tenantId: string,
  feature: keyof {
    allowAnonymous: boolean;
    allowAISummary: boolean;
    allowAdvancedAnalytics: boolean;
    allowCustomThemes: boolean;
    allowApiAccess: boolean;
  }
): Promise<boolean> {
  const tenant = await prisma.tenant.findUnique({
    where: { id: tenantId },
    select: {
      subscriptionStatus: true,
      planId: true,
      featureFlags: true,
    },
  });

  if (!tenant) return false;

  // Check explicit feature flags first
  const flags = tenant.featureFlags as Record<string, boolean>;
  if (feature in flags) return flags[feature];

  // Check plan features
  if (!tenant.planId) return false;

  const plan = await prisma.plan.findUnique({
    where: { id: tenant.planId },
    select: {
      allowAnonymous: true,
      allowAISummary: true,
      allowAdvancedAnalytics: true,
      allowCustomThemes: true,
      allowApiAccess: true,
    },
  });

  if (!plan) return false;

  // Check subscription is active
  const isActive = ["ACTIVE", "TRIALING"].includes(tenant.subscriptionStatus);
  if (!isActive) return false;

  return plan[feature] ?? false;
}

// ============================================================
// HELPERS
// ============================================================

function mapStripeStatus(status: Stripe.Subscription.Status): SubscriptionStatus {
  const map: Record<Stripe.Subscription.Status, SubscriptionStatus> = {
    active: "ACTIVE",
    trialing: "TRIALING",
    past_due: "PAST_DUE",
    canceled: "CANCELED",
    unpaid: "UNPAID",
    incomplete: "FREE",
    incomplete_expired: "FREE",
    paused: "FREE",
  };
  return map[status] ?? "FREE";
}
