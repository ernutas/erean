// lib/rate-limit.ts
// Redis-backed sliding window rate limiting

import { redis } from "@/lib/redis";
import { NextRequest, NextResponse } from "next/server";

export interface RateLimitConfig {
  windowMs: number;   // Window in milliseconds
  max: number;        // Max requests per window
  keyPrefix: string;  // Redis key prefix
  identifier?: (req: NextRequest) => string; // Custom key extractor
}

export interface RateLimitResult {
  success: boolean;
  limit: number;
  remaining: number;
  reset: number; // Unix timestamp in seconds
  retryAfter?: number;
}

// ============================================================
// SLIDING WINDOW RATE LIMITER
// ============================================================

export async function rateLimit(
  req: NextRequest,
  config: RateLimitConfig
): Promise<RateLimitResult> {
  const identifier = config.identifier
    ? config.identifier(req)
    : getDefaultIdentifier(req);

  const key = `rl:${config.keyPrefix}:${identifier}`;
  const now = Date.now();
  const windowStart = now - config.windowMs;

  try {
    // Sliding window using sorted set
    const pipeline = redis.pipeline();

    // Remove expired entries
    pipeline.zremrangebyscore(key, 0, windowStart);

    // Count current window
    pipeline.zcard(key);

    // Add current request
    pipeline.zadd(key, now, `${now}-${Math.random()}`);

    // Set expiry
    pipeline.pexpire(key, config.windowMs);

    const results = await pipeline.exec();
    const count = (results?.[1]?.[1] as number) ?? 0;

    const remaining = Math.max(0, config.max - count - 1);
    const success = count < config.max;
    const reset = Math.ceil((now + config.windowMs) / 1000);

    if (!success) {
      return {
        success: false,
        limit: config.max,
        remaining: 0,
        reset,
        retryAfter: Math.ceil(config.windowMs / 1000),
      };
    }

    return { success: true, limit: config.max, remaining, reset };
  } catch (error) {
    console.error("[Rate Limit] Redis error:", error);
    // Fail open — don't block on Redis errors
    return {
      success: true,
      limit: config.max,
      remaining: config.max,
      reset: Math.ceil((now + config.windowMs) / 1000),
    };
  }
}

// ============================================================
// RATE LIMIT MIDDLEWARE FACTORY
// ============================================================

export function createRateLimiter(config: RateLimitConfig) {
  return async (req: NextRequest): Promise<NextResponse | null> => {
    const result = await rateLimit(req, config);

    if (!result.success) {
      return NextResponse.json(
        {
          error: "Too Many Requests",
          message: "Rate limit exceeded. Please try again later.",
          retryAfter: result.retryAfter,
        },
        {
          status: 429,
          headers: {
            "X-RateLimit-Limit": result.limit.toString(),
            "X-RateLimit-Remaining": "0",
            "X-RateLimit-Reset": result.reset.toString(),
            "Retry-After": (result.retryAfter ?? 60).toString(),
          },
        }
      );
    }

    return null; // Pass through
  };
}

// ============================================================
// PRESET RATE LIMITERS
// ============================================================

export const rateLimiters = {
  // Entry creation: 30/hour per user
  createEntry: createRateLimiter({
    windowMs: 60 * 60 * 1000,
    max: 30,
    keyPrefix: "entry:create",
    identifier: (req) => {
      const userId = req.headers.get("x-user-id") || getIp(req);
      const tenantId = req.headers.get("x-tenant-id") || "global";
      return `${tenantId}:${userId}`;
    },
  }),

  // Auth: 10 attempts per 15 minutes per IP
  auth: createRateLimiter({
    windowMs: 15 * 60 * 1000,
    max: 10,
    keyPrefix: "auth",
    identifier: getIp,
  }),

  // AI features: 20/hour per user
  aiFeatures: createRateLimiter({
    windowMs: 60 * 60 * 1000,
    max: 20,
    keyPrefix: "ai",
    identifier: (req) => req.headers.get("x-user-id") || getIp(req),
  }),

  // API: 1000/hour per tenant
  api: createRateLimiter({
    windowMs: 60 * 60 * 1000,
    max: 1000,
    keyPrefix: "api",
    identifier: (req) => req.headers.get("x-tenant-id") || getIp(req),
  }),

  // Topic creation: 10/day per user
  createTopic: createRateLimiter({
    windowMs: 24 * 60 * 60 * 1000,
    max: 10,
    keyPrefix: "topic:create",
    identifier: (req) => req.headers.get("x-user-id") || getIp(req),
  }),

  // Votes: 100/hour per user
  vote: createRateLimiter({
    windowMs: 60 * 60 * 1000,
    max: 100,
    keyPrefix: "vote",
    identifier: (req) => req.headers.get("x-user-id") || getIp(req),
  }),
};

// ============================================================
// HELPERS
// ============================================================

function getIp(req: NextRequest): string {
  return (
    req.headers.get("cf-connecting-ip") ||
    req.headers.get("x-forwarded-for")?.split(",")[0].trim() ||
    req.headers.get("x-real-ip") ||
    "127.0.0.1"
  );
}

function getDefaultIdentifier(req: NextRequest): string {
  return (
    req.headers.get("x-user-id") ||
    req.headers.get("x-tenant-id") ||
    getIp(req)
  );
}
