// app/api/entries/route.ts
// POST: Create entry | GET: List entries for a topic

import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireTenant } from "@/lib/tenant/resolver";
import { requireAuth } from "@/lib/auth/session";
import { moderateContent } from "@/lib/ai/moderation";
import { queueSummaryGeneration } from "@/lib/ai/summary";
import { checkFeatureAccess } from "@/lib/stripe";
import { rateLimiters } from "@/lib/rate-limit";
import { createAuditLog } from "@/lib/audit";
import { broadcastToTenant } from "@/lib/websockets";
import DOMPurify from "isomorphic-dompurify";
import { marked } from "marked";

// ============================================================
// VALIDATION SCHEMAS
// ============================================================

const createEntrySchema = z.object({
  topicId: z.string().cuid(),
  content: z
    .string()
    .min(1, "Entry cannot be empty")
    .max(10000, "Entry too long (max 10,000 characters)")
    .trim(),
  isAnonymous: z.boolean().optional().default(false),
  parentId: z.string().cuid().optional(),
});

const listEntriesSchema = z.object({
  topicId: z.string().cuid(),
  page: z.coerce.number().int().min(1).default(1),
  pageSize: z.coerce.number().int().min(1).max(100).default(20),
  sort: z.enum(["newest", "oldest", "top"]).default("newest"),
  includeHidden: z.boolean().optional().default(false),
});

// ============================================================
// POST /api/entries — Create entry
// ============================================================

export async function POST(request: NextRequest) {
  // Rate limiting
  const rlResult = await rateLimiters.createEntry(request);
  if (rlResult) return rlResult;

  try {
    const [tenant, session] = await Promise.all([
      requireTenant(),
      requireAuth(request),
    ]);

    const body = await request.json();
    const data = createEntrySchema.safeParse(body);

    if (!data.success) {
      return NextResponse.json(
        { error: "Validation failed", details: data.error.flatten() },
        { status: 400 }
      );
    }

    const { topicId, content, isAnonymous, parentId } = data.data;

    // Check anonymous posting permission
    if (isAnonymous) {
      const canPostAnonymously = await checkFeatureAccess(tenant.id, "allowAnonymous");
      if (!canPostAnonymously) {
        return NextResponse.json(
          { error: "Anonymous posting requires a premium subscription" },
          { status: 403 }
        );
      }
    }

    // Verify topic exists and is not locked
    const topic = await prisma.topic.findUnique({
      where: { id: topicId, tenantId: tenant.id },
      select: { id: true, isLocked: true, isArchived: true },
    });

    if (!topic) {
      return NextResponse.json({ error: "Topic not found" }, { status: 404 });
    }

    if (topic.isLocked || topic.isArchived) {
      return NextResponse.json(
        { error: "Topic is locked and not accepting new entries" },
        { status: 403 }
      );
    }

    // Verify membership
    const membership = await prisma.membership.findUnique({
      where: { userId_tenantId: { userId: session.userId, tenantId: tenant.id } },
      select: { isActive: true, isBanned: true },
    });

    if (!membership || !membership.isActive || membership.isBanned) {
      return NextResponse.json(
        { error: "You are not a member of this community" },
        { status: 403 }
      );
    }

    // Check daily entry limit
    const plan = await getTenantPlan(tenant.id);
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);

    const todayEntries = await prisma.entry.count({
      where: {
        authorId: session.userId,
        tenantId: tenant.id,
        createdAt: { gte: todayStart },
      },
    });

    if (todayEntries >= plan.maxEntriesPerDay) {
      return NextResponse.json(
        { error: `Daily entry limit reached (${plan.maxEntriesPerDay}/day)` },
        { status: 429 }
      );
    }

    // Sanitize content
    const sanitizedContent = DOMPurify.sanitize(content.trim());
    const contentHtml = DOMPurify.sanitize(
      await marked.parse(sanitizedContent)
    );

    // Create entry
    const entry = await prisma.$transaction(async (tx) => {
      const newEntry = await tx.entry.create({
        data: {
          tenantId: tenant.id,
          topicId,
          authorId: isAnonymous ? null : session.userId,
          content: sanitizedContent,
          contentHtml,
          isAnonymous,
          parentId: parentId ?? null,
        },
        include: {
          author: {
            select: {
              id: true,
              displayName: true,
              username: true,
              avatarUrl: true,
            },
          },
        },
      });

      // Store anonymous identity mapping
      if (isAnonymous) {
        await tx.anonymousEntry.create({
          data: {
            entryId: newEntry.id,
            tenantId: tenant.id,
            actualUserId: session.userId,
            ipAddress:
              request.headers.get("cf-connecting-ip") ||
              request.headers.get("x-forwarded-for") ||
              null,
            userAgent: request.headers.get("user-agent") || null,
          },
        });
      }

      // Update counters
      await tx.topic.update({
        where: { id: topicId },
        data: {
          entryCount: { increment: 1 },
          updatedAt: new Date(),
        },
      });

      await tx.membership.update({
        where: { userId_tenantId: { userId: session.userId, tenantId: tenant.id } },
        data: { entryCount: { increment: 1 } },
      });

      return newEntry;
    });

    // Fire-and-forget: AI moderation
    moderateContent(sanitizedContent, entry.id, tenant.id)
      .then(async (result) => {
        if (result.autoAction === "HIDE") {
          await prisma.entry.update({
            where: { id: entry.id },
            data: { isHidden: true, hiddenAt: new Date(), hiddenBy: "AI" },
          });
        } else if (result.autoAction === "DELETE") {
          await prisma.entry.update({
            where: { id: entry.id },
            data: { isDeleted: true, deletedAt: new Date(), deletedBy: "AI" },
          });
        }
      })
      .catch(console.error);

    // Fire-and-forget: Queue summary regeneration if threshold hit
    const entryCount = await prisma.topic.findUnique({
      where: { id: topicId },
      select: { entryCount: true },
    });

    if ((entryCount?.entryCount ?? 0) % 20 === 0) {
      queueSummaryGeneration(topicId, tenant.id).catch(console.error);
    }

    // Audit log
    await createAuditLog({
      tenantId: tenant.id,
      userId: session.userId,
      action: "ENTRY_CREATED",
      entity: "Entry",
      entityId: entry.id,
      after: { topicId, isAnonymous },
      ipAddress:
        request.headers.get("cf-connecting-ip") ||
        request.headers.get("x-forwarded-for") ||
        undefined,
    });

    // Real-time broadcast
    broadcastToTenant(tenant.id, {
      type: "NEW_ENTRY",
      topicId,
      entry: {
        id: entry.id,
        content: sanitizedContent,
        author: isAnonymous ? null : entry.author,
        isAnonymous,
        createdAt: entry.createdAt,
      },
    });

    return NextResponse.json(
      {
        entry: {
          id: entry.id,
          content: entry.content,
          contentHtml: entry.contentHtml,
          isAnonymous: entry.isAnonymous,
          author: isAnonymous ? null : entry.author,
          upvotes: 0,
          downvotes: 0,
          createdAt: entry.createdAt,
        },
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("[POST /api/entries]", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

// ============================================================
// GET /api/entries — List entries
// ============================================================

export async function GET(request: NextRequest) {
  try {
    const tenant = await requireTenant();
    const session = await requireAuth(request, { optional: true });

    const searchParams = Object.fromEntries(request.nextUrl.searchParams);
    const query = listEntriesSchema.safeParse(searchParams);

    if (!query.success) {
      return NextResponse.json(
        { error: "Invalid query", details: query.error.flatten() },
        { status: 400 }
      );
    }

    const { topicId, page, pageSize, sort, includeHidden } = query.data;
    const skip = (page - 1) * pageSize;

    const isModerator = session
      ? await checkModeratorAccess(session.userId, tenant.id)
      : false;

    const orderBy =
      sort === "top"
        ? { score: "desc" as const }
        : sort === "oldest"
        ? { createdAt: "asc" as const }
        : { createdAt: "desc" as const };

    const where = {
      topicId,
      tenantId: tenant.id,
      isDeleted: false,
      ...(includeHidden && isModerator ? {} : { isHidden: false }),
    };

    const [entries, total] = await Promise.all([
      prisma.entry.findMany({
        where,
        select: {
          id: true,
          content: true,
          contentHtml: true,
          isAnonymous: true,
          isHidden: true,
          isPinned: true,
          upvotes: true,
          downvotes: true,
          score: true,
          createdAt: true,
          updatedAt: true,
          isEdited: true,
          parentId: true,
          author: {
            select: {
              id: true,
              displayName: true,
              username: true,
              avatarUrl: true,
            },
          },
          _count: { select: { replies: true } },
          // Include user vote if authenticated
          votes: session
            ? {
                where: { userId: session.userId },
                select: { value: true },
                take: 1,
              }
            : false,
        },
        orderBy: [{ isPinned: "desc" }, orderBy],
        skip,
        take: pageSize,
      }),
      prisma.entry.count({ where }),
    ]);

    // Mask author for anonymous entries (unless moderator)
    const maskedEntries = entries.map((entry) => ({
      ...entry,
      author: entry.isAnonymous && !isModerator ? null : entry.author,
      userVote: entry.votes?.[0]?.value ?? null,
      votes: undefined,
    }));

    return NextResponse.json({
      entries: maskedEntries,
      pagination: {
        page,
        pageSize,
        total,
        totalPages: Math.ceil(total / pageSize),
        hasMore: skip + entries.length < total,
      },
    });
  } catch (error) {
    console.error("[GET /api/entries]", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

// ============================================================
// HELPERS
// ============================================================

async function checkModeratorAccess(
  userId: string,
  tenantId: string
): Promise<boolean> {
  const membership = await prisma.membership.findUnique({
    where: { userId_tenantId: { userId, tenantId } },
    select: { role: true },
  });
  return ["OWNER", "ADMIN", "MODERATOR"].includes(membership?.role ?? "");
}

async function getTenantPlan(
  tenantId: string
): Promise<{ maxEntriesPerDay: number }> {
  const tenant = await prisma.tenant.findUnique({
    where: { id: tenantId },
    select: { plan: { select: { maxEntriesPerDay: true } } },
  });
  return tenant?.plan ?? { maxEntriesPerDay: 50 };
}
