// lib/websockets/index.ts
// WebSocket server using ws + Redis pub/sub for horizontal scaling

import { WebSocketServer, WebSocket } from "ws";
import { redis, redisSub } from "@/lib/redis";
import type { IncomingMessage } from "http";
import type { Server } from "http";

// ============================================================
// CONNECTION REGISTRY (in-process)
// Connections per tenant for broadcasting
// ============================================================

const connections = new Map<string, Set<WebSocket>>();

// ============================================================
// WS MESSAGE TYPES
// ============================================================

export type WSMessage =
  | { type: "NEW_ENTRY"; topicId: string; entry: unknown }
  | { type: "ENTRY_UPDATED"; entryId: string; update: unknown }
  | { type: "NOTIFICATION"; notification: unknown }
  | { type: "TRENDING_UPDATE"; topics: unknown[] }
  | { type: "PING" }
  | { type: "PONG" };

// ============================================================
// INITIALIZE WS SERVER
// ============================================================

export function initWebSocketServer(httpServer: Server): WebSocketServer {
  const wss = new WebSocketServer({
    server: httpServer,
    path: "/ws",
    verifyClient: async ({ req }: { req: IncomingMessage }) => {
      // Verify auth token from URL params
      const url = new URL(req.url || "", "http://localhost");
      const token = url.searchParams.get("token");
      return !!token; // Further validation in connection handler
    },
  });

  wss.on("connection", (ws: WebSocket, req: IncomingMessage) => {
    handleConnection(ws, req);
  });

  // Subscribe to Redis pub/sub for cross-process broadcasting
  subscribeToRedis();

  // Heartbeat
  setInterval(() => {
    wss.clients.forEach((ws) => {
      if ((ws as WebSocket & { isAlive?: boolean }).isAlive === false) {
        ws.terminate();
        return;
      }
      (ws as WebSocket & { isAlive?: boolean }).isAlive = false;
      ws.ping();
    });
  }, 30000);

  return wss;
}

// ============================================================
// CONNECTION HANDLER
// ============================================================

async function handleConnection(ws: WebSocket, req: IncomingMessage) {
  const url = new URL(req.url || "", "http://localhost");
  const token = url.searchParams.get("token");
  const tenantId = url.searchParams.get("tenantId");

  if (!token || !tenantId) {
    ws.close(4001, "Missing authentication");
    return;
  }

  // Validate token
  const session = await validateWSToken(token);
  if (!session) {
    ws.close(4002, "Invalid token");
    return;
  }

  // Register connection
  if (!connections.has(tenantId)) {
    connections.set(tenantId, new Set());
  }
  connections.get(tenantId)!.add(ws);

  // Store metadata on ws
  (ws as WebSocket & { tenantId?: string; userId?: string }).tenantId = tenantId;
  (ws as WebSocket & { tenantId?: string; userId?: string }).userId = session.userId;
  (ws as WebSocket & { isAlive?: boolean }).isAlive = true;

  // Heartbeat
  ws.on("pong", () => {
    (ws as WebSocket & { isAlive?: boolean }).isAlive = true;
  });

  ws.on("message", (data: Buffer) => {
    try {
      const msg = JSON.parse(data.toString()) as WSMessage;
      if (msg.type === "PING") {
        ws.send(JSON.stringify({ type: "PONG" }));
      }
    } catch {
      // Ignore invalid messages
    }
  });

  ws.on("close", () => {
    const tenantWs = connections.get(tenantId);
    if (tenantWs) {
      tenantWs.delete(ws);
      if (tenantWs.size === 0) {
        connections.delete(tenantId);
      }
    }
  });

  ws.on("error", (error) => {
    console.error("[WS] Error:", error);
  });

  // Send connected acknowledgment
  ws.send(JSON.stringify({ type: "CONNECTED", userId: session.userId }));
}

// ============================================================
// BROADCAST (via Redis pub/sub for horizontal scaling)
// ============================================================

export async function broadcastToTenant(
  tenantId: string,
  message: Omit<WSMessage, "PING" | "PONG">
): Promise<void> {
  const channel = `ws:tenant:${tenantId}`;
  await redis.publish(channel, JSON.stringify(message));
}

export async function broadcastToUser(
  tenantId: string,
  userId: string,
  message: Omit<WSMessage, "PING" | "PONG">
): Promise<void> {
  const channel = `ws:user:${tenantId}:${userId}`;
  await redis.publish(channel, JSON.stringify(message));
}

// ============================================================
// REDIS PUB/SUB (receive from other instances)
// ============================================================

function subscribeToRedis(): void {
  redisSub.psubscribe("ws:tenant:*", "ws:user:*");

  redisSub.on("pmessage", (_pattern: string, channel: string, message: string) => {
    try {
      const parts = channel.split(":");
      const type = parts[1]; // "tenant" or "user"
      const tenantId = parts[2];
      const userId = parts[3]; // Only for user-specific messages

      const data = JSON.parse(message);
      const payload = JSON.stringify(data);

      if (type === "tenant") {
        // Broadcast to all connections in tenant
        const tenantConnections = connections.get(tenantId);
        tenantConnections?.forEach((ws) => {
          if (ws.readyState === WebSocket.OPEN) {
            ws.send(payload);
          }
        });
      } else if (type === "user" && userId) {
        // Broadcast to specific user in tenant
        const tenantConnections = connections.get(tenantId);
        tenantConnections?.forEach((ws) => {
          const wsWithMeta = ws as WebSocket & { userId?: string };
          if (ws.readyState === WebSocket.OPEN && wsWithMeta.userId === userId) {
            ws.send(payload);
          }
        });
      }
    } catch (error) {
      console.error("[WS Redis] Error:", error);
    }
  });
}

// ============================================================
// AUTH HELPER
// ============================================================

async function validateWSToken(token: string): Promise<{ userId: string } | null> {
  const sessionKey = `session:${token}`;
  const cached = await redis.get(sessionKey);
  if (cached) {
    try {
      return JSON.parse(cached);
    } catch {
      return null;
    }
  }
  return null;
}
