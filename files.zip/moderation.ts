// lib/ai/moderation.ts
// AI-powered content moderation with toxicity, hate speech, and spam detection

import { openai } from "@/lib/openai";
import { prisma } from "@/lib/prisma";
import { redis } from "@/lib/redis";
import type { AIFlagType } from "@prisma/client";

// ============================================================
// MODERATION RESULT
// ============================================================

export interface ModerationResult {
  passed: boolean;           // true = safe, false = flagged
  confidence: number;        // 0-1
  flags: FlagResult[];
  requiresHumanReview: boolean;
  autoAction?: "HIDE" | "DELETE" | null;
  rawResponse?: unknown;
}

export interface FlagResult {
  type: AIFlagType;
  confidence: number;
  label: string;
}

// Thresholds for automated actions
const THRESHOLDS = {
  AUTO_HIDE: 0.85,     // Hide without human review
  AUTO_DELETE: 0.97,   // Delete without human review  
  HUMAN_REVIEW: 0.60,  // Flag for human review
} as const;

// ============================================================
// OPENAI MODERATION + CUSTOM CLASSIFICATION
// ============================================================

export async function moderateContent(
  content: string,
  entryId: string,
  tenantId: string
): Promise<ModerationResult> {
  // Check cache (avoid re-moderating same content)
  const contentHash = await hashString(content);
  const cacheKey = `moderation:${contentHash}`;
  const cached = await redis.get(cacheKey);
  if (cached) {
    return JSON.parse(cached) as ModerationResult;
  }

  try {
    // 1. OpenAI Moderation API (fast, cheap)
    const [openAIResult, customResult] = await Promise.all([
      runOpenAIModeration(content),
      runCustomClassification(content),
    ]);

    // Merge results (take highest confidence flags)
    const allFlags = mergeFlags(openAIResult.flags, customResult.flags);
    const highestConfidence = Math.max(...allFlags.map((f) => f.confidence), 0);
    const passed = highestConfidence < THRESHOLDS.HUMAN_REVIEW;

    const result: ModerationResult = {
      passed,
      confidence: highestConfidence,
      flags: allFlags,
      requiresHumanReview:
        highestConfidence >= THRESHOLDS.HUMAN_REVIEW &&
        highestConfidence < THRESHOLDS.AUTO_HIDE,
      autoAction:
        highestConfidence >= THRESHOLDS.AUTO_DELETE
          ? "DELETE"
          : highestConfidence >= THRESHOLDS.AUTO_HIDE
          ? "HIDE"
          : null,
      rawResponse: { openAI: openAIResult.raw, custom: customResult.raw },
    };

    // Cache for 10 minutes
    await redis.setex(cacheKey, 600, JSON.stringify(result));

    // Persist AI flags to DB
    await persistFlags(result, entryId, tenantId);

    // Update entry moderation score
    await prisma.entry.update({
      where: { id: entryId },
      data: {
        aiModerationScore: highestConfidence,
        aiModerationLabel: allFlags[0]?.label ?? null,
        aiFlaggedAt: allFlags.length > 0 ? new Date() : null,
      },
    });

    return result;
  } catch (error) {
    console.error("[AI Moderation] Error:", error);
    // Fail open — don't block content on moderation errors
    return {
      passed: true,
      confidence: 0,
      flags: [],
      requiresHumanReview: true, // Escalate for manual review
      autoAction: null,
    };
  }
}

// ============================================================
// OPENAI MODERATION API
// ============================================================

async function runOpenAIModeration(content: string): Promise<{
  flags: FlagResult[];
  raw: unknown;
}> {
  const response = await openai.moderations.create({
    model: "omni-moderation-latest",
    input: content,
  });

  const result = response.results[0];
  const flags: FlagResult[] = [];

  if (result.categories["hate"] && result.category_scores["hate"] > 0.3) {
    flags.push({
      type: "HATE_SPEECH",
      confidence: result.category_scores["hate"],
      label: "Hate speech detected",
    });
  }

  if (result.categories["harassment"] && result.category_scores["harassment"] > 0.4) {
    flags.push({
      type: "TOXICITY",
      confidence: result.category_scores["harassment"],
      label: "Harassment detected",
    });
  }

  if (result.categories["violence"] && result.category_scores["violence"] > 0.5) {
    flags.push({
      type: "VIOLENCE",
      confidence: result.category_scores["violence"],
      label: "Violence detected",
    });
  }

  if (result.categories["self-harm"] && result.category_scores["self-harm"] > 0.5) {
    flags.push({
      type: "SELF_HARM",
      confidence: result.category_scores["self-harm"],
      label: "Self-harm content detected",
    });
  }

  return { flags, raw: result };
}

// ============================================================
// CUSTOM GPT-4o-mini CLASSIFICATION
// For spam detection and nuanced toxicity
// ============================================================

async function runCustomClassification(content: string): Promise<{
  flags: FlagResult[];
  raw: unknown;
}> {
  const response = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [
      {
        role: "system",
        content: `You are a content moderation classifier. Analyze the content and return ONLY a JSON object with this exact structure:
{
  "spam": { "detected": boolean, "confidence": number },
  "toxicity": { "detected": boolean, "confidence": number },
  "hate_speech": { "detected": boolean, "confidence": number },
  "misinformation": { "detected": boolean, "confidence": number }
}
Confidence is 0.0-1.0. Be conservative — only flag clearly problematic content.`,
      },
      { role: "user", content: content.slice(0, 2000) }, // Trim to save tokens
    ],
    max_tokens: 200,
    temperature: 0,
    response_format: { type: "json_object" },
  });

  const raw = response.choices[0].message.content || "{}";
  const parsed = JSON.parse(raw);
  const flags: FlagResult[] = [];

  const typeMap: Record<string, AIFlagType> = {
    spam: "SPAM",
    toxicity: "TOXICITY",
    hate_speech: "HATE_SPEECH",
    misinformation: "MISINFORMATION",
  };

  for (const [key, flagType] of Object.entries(typeMap)) {
    const item = parsed[key];
    if (item?.detected && item.confidence > 0.5) {
      flags.push({
        type: flagType,
        confidence: item.confidence,
        label: `${key.replace("_", " ")} detected`,
      });
    }
  }

  return { flags, raw: parsed };
}

// ============================================================
// HELPERS
// ============================================================

function mergeFlags(a: FlagResult[], b: FlagResult[]): FlagResult[] {
  const merged = new Map<AIFlagType, FlagResult>();

  for (const flag of [...a, ...b]) {
    const existing = merged.get(flag.type);
    if (!existing || flag.confidence > existing.confidence) {
      merged.set(flag.type, flag);
    }
  }

  return Array.from(merged.values()).sort((a, b) => b.confidence - a.confidence);
}

async function persistFlags(
  result: ModerationResult,
  entryId: string,
  tenantId: string
): Promise<void> {
  if (result.flags.length === 0) return;

  await prisma.aIFlag.createMany({
    data: result.flags.map((flag) => ({
      tenantId,
      entryId,
      flagType: flag.type,
      confidence: flag.confidence,
      label: flag.label,
      rawResponse: result.rawResponse as object,
      model: "gpt-4o-mini+omni-moderation",
    })),
  });
}

async function hashString(str: string): Promise<string> {
  // Simple hash for cache key
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash = hash & hash;
  }
  return Math.abs(hash).toString(36);
}

// ============================================================
// BULK REMODERATE (admin action)
// ============================================================

export async function remoderateTenant(
  tenantId: string,
  sinceDays: number = 7
): Promise<void> {
  const since = new Date(Date.now() - sinceDays * 24 * 60 * 60 * 1000);

  const entries = await prisma.entry.findMany({
    where: {
      tenantId,
      isDeleted: false,
      createdAt: { gte: since },
      aiFlaggedAt: null,
    },
    select: { id: true, content: true },
    take: 500,
  });

  for (const entry of entries) {
    await moderateContent(entry.content, entry.id, tenantId);
    await new Promise((r) => setTimeout(r, 100)); // Rate limiting
  }
}
