// middleware.ts — Multi-tenant resolution middleware
// Runs on Edge Runtime for low-latency tenant identification

import { NextRequest, NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";

// ============================================================
// TENANT RESOLUTION STRATEGY
// Priority: custom domain → subdomain → path prefix → default
// ============================================================

const PUBLIC_PATHS = [
  "/_next",
  "/api/auth",
  "/api/webhooks",
  "/favicon.ico",
  "/robots.txt",
  "/sitemap.xml",
];

const PLATFORM_DOMAIN = process.env.NEXT_PUBLIC_PLATFORM_DOMAIN || "lexicon.app";

export async function middleware(request: NextRequest) {
  const { pathname, hostname } = request.nextUrl;

  // Skip public paths
  if (PUBLIC_PATHS.some((p) => pathname.startsWith(p))) {
    return NextResponse.next();
  }

  // Resolve tenant from request
  const tenantContext = resolveTenantFromRequest(request);

  // Attach tenant context to headers for downstream use
  const headers = new Headers(request.headers);
  headers.set("x-tenant-id", tenantContext.tenantId || "");
  headers.set("x-tenant-slug", tenantContext.slug || "");
  headers.set("x-tenant-domain", tenantContext.domain || "");
  headers.set("x-tenant-type", tenantContext.type);

  // Handle Super Admin platform routes (admin.lexicon.app)
  if (hostname === `admin.${PLATFORM_DOMAIN}`) {
    const token = await getToken({ req: request });
    if (!token || token.globalRole !== "SUPER_ADMIN") {
      return NextResponse.redirect(
        new URL(`https://${PLATFORM_DOMAIN}/auth/signin?callbackUrl=${encodeURIComponent(request.url)}`)
      );
    }
    return NextResponse.next({ request: { headers } });
  }

  // Inject tenant headers into response
  const response = NextResponse.next({ request: { headers } });

  // Cache headers for CDN
  response.headers.set("Vary", "Host");

  return response;
}

interface TenantContext {
  tenantId?: string;
  slug?: string;
  domain?: string;
  type: "subdomain" | "custom_domain" | "platform" | "unknown";
}

function resolveTenantFromRequest(request: NextRequest): TenantContext {
  const hostname = request.headers.get("host") || request.nextUrl.hostname;
  const cleanHost = hostname.replace(/:\d+$/, ""); // Remove port

  // 1. Check for custom domain (not platform domain)
  if (!cleanHost.endsWith(`.${PLATFORM_DOMAIN}`) && cleanHost !== PLATFORM_DOMAIN) {
    return {
      domain: cleanHost,
      type: "custom_domain",
    };
  }

  // 2. Check for subdomain
  if (cleanHost.endsWith(`.${PLATFORM_DOMAIN}`)) {
    const subdomain = cleanHost.replace(`.${PLATFORM_DOMAIN}`, "");
    if (subdomain && subdomain !== "www" && subdomain !== "admin") {
      return {
        slug: subdomain,
        type: "subdomain",
      };
    }
  }

  // 3. Platform domain itself
  return {
    type: "platform",
  };
}

export const config = {
  matcher: [
    "/((?!_next/static|_next/image|favicon.ico).*)",
  ],
};
